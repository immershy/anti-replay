package com.cmcc.arp.exception;

/**
 * Created by zmcc on 17/4/5.
 */
public class InvalidSignException extends RuntimeException {
}
