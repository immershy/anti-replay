package com.cmcc.arp.handler;

/**
 * Created by zmcc on 17/4/5.
 */
public class RedisRequestStore implements RequestStore {


    public void store(String value) {

    }

    public Boolean contains(String value) {
        return null;
    }
}
