package com.cmcc.arp.util;

/**
 * Created by zmcc on 17/4/5.
 */
public class Config {

    public static String private_key = "r8rw4d1kjwqgqqto9dwsq3ew0ip2np1b";

    public static String input_charset = "utf-8";
}
